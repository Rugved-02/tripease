package com.tripease.flight.controller;

import com.tripease.flight.dto.*;
import com.tripease.flight.repo.FlightRepository;
import com.tripease.flight.service.FlightSearchService;
import com.tripease.flight.service.InventoryManagementService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.tripease.flight.model.Flight;
import com.tripease.flight.model.FlightSeat;
import com.tripease.flight.service.FlightService;

import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@RequestMapping("/flight")
@RequiredArgsConstructor
@RestController
public class FlightController {

    private final FlightService flightService;
    private final InventoryManagementService inventoryManagementService;
    private final FlightSearchService searchService;

    private final FlightRepository flightRepository;

    @GetMapping("/search")
    public ResponseEntity<List<FlightSearchResponseDTO>> search(
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam int passengers) {

        List<FlightSearchResponseDTO> flights = searchService.searchAvailableFlights(from, to, date, passengers);
        return ResponseEntity.ok(flights);
    }

    @PostMapping("/add")
    public ResponseEntity<FlightResponseDTO> addFlight(@RequestBody FlightRequestDTO requestDTO) {
        FlightResponseDTO response = flightService.registerNewFlight(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

//    @GetMapping("/search")
//    public ResponseEntity<List<Flight>> searchFlightsLatest(
//            @RequestParam String from,
//            @RequestParam String to,
//            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate departureDate,
//            @RequestParam int passengers) {
//
//        List<Flight> results = flightService.searchFlightsLatest(from, to, departureDate, passengers);
//        return ResponseEntity.ok(results);
//    }

//    @PostMapping("/add")
//    public ResponseEntity<Flight> addFlightLatest(@RequestBody FlightRequestDTO flightRequestDTO) {
//        return ResponseEntity.ok(flightService.createFlightWithSeats(flightRequestDTO));
//    }
//
//    @PostMapping()
//    public ResponseEntity<Flight> addFlight(@RequestBody FlightRequestDTO flightDTO) {
//        Flight savedFlight = flightService.createFlight(flightDTO);
//        return new ResponseEntity<>(savedFlight, HttpStatus.CREATED);
//    }

//    @PostMapping("/{flightId}/seats")
//    public ResponseEntity<FlightSeat> addSeat(@PathVariable Long flightId, @RequestBody FlightSeatRequestDTO seat) {
//        FlightSeat savedSeat = flightService.addSeat(flightId, seat);
//        return new ResponseEntity<>(savedSeat, HttpStatus.CREATED);
//    }
//
//    @PutMapping("/seats/{seatId}/book")
//    public ResponseEntity<FlightSeat> bookSeat(
//            @PathVariable Long seatId,
//            @RequestParam(defaultValue = "1") Integer count) {
//        FlightSeat updatedSeat = flightService.bookSeat(seatId, count);
//        return ResponseEntity.ok(updatedSeat);
//    }
//    @GetMapping("/all")
//public ResponseEntity<List<Flight>> getAllFlights() {
//    return ResponseEntity.ok(flightService.getAllFlights());
//}
//    @GetMapping
//    public ResponseEntity<List<Flight>> search(
//            @RequestParam String depPlace,
//            @RequestParam String arrPlace,
//            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm") LocalDateTime depTime) {
//                LocalDateTime start = depTime.toLocalDate().atStartOfDay();
//    LocalDateTime end = depTime.toLocalDate().atTime(23, 59, 59);
//        List<Flight> results = flightService.searchFlights(depPlace, arrPlace, start, end);
//        return ResponseEntity.ok(results);
//    }

//    @GetMapping("/{flightId}")
//    public ResponseEntity<FlightResponseDTO> getDetails(@PathVariable Long flightId) {
//        Flight flight = flightService.getFlightById(flightId);
//        FlightResponseDTO responseDTO = FlightResponseDTO.builder()
//                .flightId(flight.getFlightId())
//                .depPlace(flight.getDepPlace())
//                .arrPlace(flight.getArrPlace())
//                .depTime(flight.getDepTime())
//                .message("Flight details retrieved successfully")
//                .build();
//        return ResponseEntity.ok(responseDTO);
//    }
//
//    @GetMapping("/{flightId}/seats")
//    public ResponseEntity<List<FlightSeat>> getSeats(@PathVariable Long flightId) {
//        List<FlightSeat> seats = flightService.getSeatsByFlightId(flightId);
//        return ResponseEntity.ok(seats);
//    }

}