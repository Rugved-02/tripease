package com.tripease.flight.exception;

// Custom exception for business logic errors
public class FlightNotFoundException extends RuntimeException {
    public FlightNotFoundException(String message) {
        super(message);
    }
}