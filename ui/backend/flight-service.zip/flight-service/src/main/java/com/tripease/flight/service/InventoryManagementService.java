package com.tripease.flight.service;

import com.tripease.flight.model.ClassType;
import com.tripease.flight.model.Flight;
import com.tripease.flight.model.FlightInventory;
import com.tripease.flight.model.FlightSeat;
import com.tripease.flight.repo.FlightInventoryRepository;
import com.tripease.flight.repo.FlightRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
@RequiredArgsConstructor
@Slf4j
public class InventoryManagementService {

    private final FlightInventoryRepository inventoryRepository;
    private final FlightRepository flightRepository;


    @Transactional
    public void reserveSeats(Long flightId, LocalDate date, ClassType type, int qty) {
        FlightInventory inv = inventoryRepository
                .findByFlight_FlightIdAndTravelDateAndClassType(flightId, date, type)
                .orElseThrow(() -> new RuntimeException("Inventory not found"));

        if (inv.getAvailableSeats() < qty) {
            throw new RuntimeException("Seats just sold out!");
        }

        inv.setAvailableSeats(inv.getAvailableSeats() - qty);
        inventoryRepository.save(inv);
    }

    @Transactional
    public void releaseSeats(Long flightId, LocalDate date, ClassType type, int qty) {
        FlightInventory inv = inventoryRepository
                .findByFlight_FlightIdAndTravelDateAndClassType(flightId, date, type)
                .orElseThrow(() -> new RuntimeException("Inventory record missing during release"));

        inv.setAvailableSeats(inv.getAvailableSeats() + qty);
        inventoryRepository.save(inv);
    }

    /**
     * Called from the Controller when a new flight is born.
     */
    @Transactional
    public void initializeNewFlightInventory(Flight flight) {
        createInventoryForDateRange(flight, LocalDate.now(), LocalDate.now().plusDays(90));
    }

    /**
     * Scheduled Job to keep the 90-day window moving.
     */
    @Scheduled(cron = "0 0 0 * * *")
    @Transactional
    public void rotateDailyInventory() {
        inventoryRepository.deleteByTravelDateBefore(LocalDate.now());

        LocalDate ninetiethDay = LocalDate.now().plusDays(90);
        List<Flight> allFlights = flightRepository.findAll();

        for (Flight f : allFlights) {
            createInventoryForDateRange(f, ninetiethDay, ninetiethDay);
        }
    }

    private void createInventoryForDateRange(Flight flight, LocalDate start, LocalDate end) {
        for (LocalDate date = start; !date.isAfter(end); date = date.plusDays(1)) {
            // Using your agreed-upon 'seats' list
            if (flight.getSeats() != null) {
                for (FlightSeat seatTemplate : flight.getSeats()) {

                    // Check if already exists to prevent unique constraint errors
                    if (!inventoryRepository.existsByFlightAndTravelDateAndClassType(
                            flight, date, seatTemplate.getClassType())) {

                        FlightInventory inv = FlightInventory.builder()
                                .flight(flight)
                                .travelDate(date)
                                .classType(seatTemplate.getClassType())
                                .availableSeats(seatTemplate.getTotalCapacity())
                                .build();

                        inventoryRepository.save(inv);
                    }
                }
            }
        }
    }
}